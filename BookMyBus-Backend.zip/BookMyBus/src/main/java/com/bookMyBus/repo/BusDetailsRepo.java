package com.bookMyBus.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookMyBus.pojo.BusDetails;


public interface BusDetailsRepo extends JpaRepository<BusDetails, Integer> {
	//Method to find bus details by route
	@Query("select f from BusDetails f where f.arrivalBusstop = ?1 and f.departureBusstop = ?2") //JPQL 
	public List<BusDetails> findByRouteDate(String sourceBusstop,String destinationBusstop);
	
	//Method to find distinct arrival bus stops
	@Query("SELECT DISTINCT b.arrivalBusstop FROM BusDetails b")
    List<String> findDistinctArrivalBusstops();

	//Method to find distinct departure bus stops
    @Query("SELECT DISTINCT b.departureBusstop FROM BusDetails b")
    List<String> findDistinctDepartureBusstops();
}
