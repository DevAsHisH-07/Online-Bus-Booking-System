package com.bookMyBus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyBusApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyBusApplication.class, args);
	}

}
